# IPOVista 🇮🇳

**Indian IPO Analytics Dashboard** — Search any IPO from 2010–2022, view subscription data, listing gains, investor sentiment, peer comparisons, and market-wide trends.

## Features
- 🔍 **Company Search** — Type any company name for instant analysis
- 📊 **Subscription Breakdown** — QIB, HNI, RII charts
- 📈 **Benchmark Comparison** — vs. same-year average and all-time average
- 🎯 **Investor Sentiment Score** — Composite score from 0–100
- 🏆 **Leaderboard** — Best gainers, worst performers, most subscribed, largest IPOs
- 🌐 **Market Overview** — Year-by-year trends, distribution, IPO count

## Data
319 Indian IPOs from 2010–2022. Source: `data.js` (compiled from `Indian_IPO_Market_Data.csv`).

## Deploy on Vercel

1. Push this repository to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project**
3. Import the `IPOVista` GitHub repository
4. Leave all settings as default (auto-detects static site)
5. Click **Deploy** ✅

No build step required — pure HTML/CSS/JS.

## Local Development

```bash
# Just open index.html in a browser, or use any static server:
npx serve .
# or
python3 -m http.server 8080
```

## File Structure

```
IPOVista/
├── index.html      # Main HTML
├── style.css       # All styles
├── app.js          # All logic + Chart.js rendering
├── data.js         # IPO dataset (319 records)
├── vercel.json     # Vercel deployment config
└── README.md
```

## Tech Stack
- Vanilla HTML/CSS/JS (no framework)
- [Chart.js 4](https://www.chartjs.org/) for visualizations
- Google Fonts (Syne + DM Mono + Inter)
